/**
* @file main.c
* @brief Description
* @date 2018-1-1
* @author name of author
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "debug.h"
#include "memory.h"

int main(int argc, char *argv[]){
	
	pid_t pidneto, pid, pidf2;

	pid = fork();

	if (pid == 0) {			// Processo filho 1
		
		pidneto=fork();
		if(pidneto==0){
			printf("Eu sou o neto\n");
			exit(0);
		}
		waitpid(pidneto,0,0);
		printf("Eu sou o filho 1\n");		
		exit(0);			// Terminar processo filho 1
	} else if (pid > 0) {	// Processo pai 
		pidf2 = fork();
		if(pidf2 == 0){
			printf("Eu sou o filho 2\n");
			exit(0);
		}
		waitpid(pidf2,0,0);
		printf("Eu sou o pai\n");
		exit(0);
	}

	return 0;
}

