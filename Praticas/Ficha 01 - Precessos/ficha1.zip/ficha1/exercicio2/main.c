/**
* @file main.c
* @brief Description
* @date 2018-1-1
* @author name of author
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "debug.h"
#include "memory.h"

int main(int argc, char *argv[]){

	pid_t pid,  pid1, pid2; //neto

	pid = fork();
	
	if (pid == 0) {			// Processo filho 
		printf("Eu sou o Filho 1\n");
		pid2 = fork();
		waitpid(pid2,NULL,0);
		if(pid2==0){
			printf("Eu sou o neto\n");
			exit(0);
		}
		exit(0);			// Terminar processo filho
	
	}
		pid1=fork();
	if (pid1 == 0){
		printf("Eu sou o filho 2\n");
		waitpid(pid,NULL,0);
		exit(0);
	} else if (pid > 0) {	// Processo pai 
		printf("Eu sou o pai\n");
		waitpid(pid,NULL,0);
		waitpid(pid1,NULL,0);
		exit(0);
	} else					// < 0 - erro
		ERROR(2, "Erro na execucao do fork()");

	return 0;
}

