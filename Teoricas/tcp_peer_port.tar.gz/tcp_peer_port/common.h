#ifndef _COMUM_H_
#define _COMUM_H_

/*
 * definições e estruturas comuns ao cliente e ao servidor
 */
#include <stdint.h>
 
 
int show_local_port(int sock);
int show_remote_port(int sock);
uint16_t validate_port_number(int port);

#endif
