#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <assert.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include "debug.h"
#include "server_args.h"
#include "common.h"


int accept_print_end(int sock);
int setup_TCP_server(int port, int backlog);

int main(int argc, char *argv[]) 
{
	struct gengetopt_args_info args;

	// cmdline_parser: deve ser a primeira linha de código no main
	if( cmdline_parser(argc, argv, &args) )
		ERROR(99, "Erro: execução de cmdline_parser\n");
	
	int port = args.port_arg;
#define PORT_MAX (1<<16)
	if( port < 0 || port >= PORT_MAX){
		fprintf(stderr,"error: invalid port '%hu'\n", port);
		exit(2);
	}

	// libertar recurso (cmdline_parser)
	cmdline_parser_free(&args);	

	printf("SOMAXCONN=%d\n", SOMAXCONN);
	int listen_sock = setup_TCP_server(port, SOMAXCONN);
	accept_print_end(listen_sock);


	exit(0);
}

int accept_print_end(int sock){
	struct sockaddr_in clnt_addr;
	socklen_t addr_len = sizeof(clnt_addr);

	int clnt_sock;
	char IP_clnt_S[32];

	while(1){
		printf("[INFO] ready to accept (sock=%d)...\n", sock);
		clnt_sock = accept(sock, (struct sockaddr*)&clnt_addr, 
								&addr_len);
		if( clnt_sock == -1 ){
			fprintf(stderr,"ERROR: cannot accept: %s\n",
				       			strerror(errno));
			exit(1);
			//continue;
		}
		inet_ntop(AF_INET,&clnt_addr.sin_addr, IP_clnt_S, addr_len);
		int clnt_port = ntohs(clnt_addr.sin_port);
		printf("client IP: '%s'\n", IP_clnt_S);
		printf("client port: '%hu'\n", clnt_port);


		show_remote_port(clnt_sock);
		show_local_port(clnt_sock);

	}
	return 1;
}


int setup_TCP_server(int port, int backlog){

	/*criar socket */
	int serv_sock = socket(AF_INET,SOCK_STREAM,0);
	if( serv_sock == -1 ){
		ERROR(3,"Cannot create socket");
	}

	struct sockaddr_in bind_addr;
	memset(&bind_addr,0,sizeof(bind_addr));
	bind_addr.sin_family = AF_INET;
	bind_addr.sin_port = htons(port);
	bind_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	if ( bind(serv_sock,(struct sockaddr*)&bind_addr, 
				sizeof(bind_addr)) == -1){
		ERROR(4,"Cannot bind to port %d", port);
	}

	if( listen(serv_sock, backlog) == -1 ){
		ERROR(5,"Cannot listen (backlog=%d)\n", backlog);
	}

	return serv_sock;
}



