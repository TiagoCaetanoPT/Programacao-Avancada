#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include "debug.h"
#include "client_args.h"
#include "common.h"

unsigned short validate_port_number(int port);
int connect_to_TCP_server(char *ip_S,unsigned short port);

int main(int argc, char *argv[]) {
	struct gengetopt_args_info args;

	// cmdline_parser: deve ser a primeira linha de código no main
	if( cmdline_parser(argc, argv, &args) )
		ERROR(99, "Erro: execução de cmdline_parser\n");

	uint16_t port = validate_port_number( args.port_arg );

	// creates socket and try to connect to remote server
	int sock = connect_to_TCP_server(args.ip_arg,port);

	printf("[CLIENT]\n");
	show_local_port(sock);
	show_remote_port(sock);
	// libertar recurso (cmdline_parser)
	close(sock);
	cmdline_parser_free(&args);	
	exit(0);
}

int connect_to_TCP_server(char *ip_S,unsigned short port){
	/*criar socket */
	int sock = socket(AF_INET,SOCK_STREAM,0);
	if( sock == -1 ){
		ERROR(3,"Cannot create socket SOCK_STREAM");
	}

	struct sockaddr_in serv_addr;
	memset(&serv_addr,0,sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(port);
	int ret_pton = inet_pton(AF_INET, ip_S, &serv_addr.sin_addr);
	if( ret_pton == -1 ){
		ERROR(4,"Cannot inet_pton of '%s'", ip_S);
	}else if( ret_pton == 0 ){
		fprintf(stderr,"invalid IP address '%s'\n", ip_S);
		exit(5);
	}

	socklen_t serv_addr_len = sizeof(serv_addr);
	int ret_connect = connect(sock, (struct sockaddr*)&serv_addr,
							serv_addr_len);
	if( ret_connect == -1 ){
		ERROR(6,"Cannot connect to '%s'", ip_S);
	}

	/* Still here? Good */
	return sock;
}

