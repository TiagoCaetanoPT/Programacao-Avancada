
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include "common.h"

/* Get local IP / local port for sock */
int show_local_port(int sock){
	struct sockaddr_in local_addr_in;
	socklen_t addr_len = sizeof(local_addr_in);
	int ret_sockname = getsockname(sock,
			(struct sockaddr*)&local_addr_in,&addr_len);

	if( ret_sockname == -1 ){
		fprintf(stderr, "Can't getsockname:%s\n",strerror(errno));
		return -1;
	}
	printf("Local port of socket=%hu\n", ntohs(local_addr_in.sin_port));
	return 0;
}

int show_remote_port(int sock){
	struct sockaddr_in remote_addr_in;
	socklen_t addr_len = sizeof(remote_addr_in);
	int ret_peername = getpeername(sock,
			(struct sockaddr*)&remote_addr_in,&addr_len);

	if( ret_peername == -1 ){
		fprintf(stderr, "Can't getpeername:%s\n",strerror(errno));
		return -1;
	}
	printf("Remote port of socket=%hu\n", ntohs(remote_addr_in.sin_port));
	return 0;
}

#define PORT_MAX (1<<16)
/* Function to validate a port (check whether the value is in range [0,2¹⁶-1]
 * @param port	[IN] port to validate.
 * @return on invalid port the function terminates the application
 * 2017-11-28
 */
uint16_t validate_port_number(int port){
	if( port < 0 || port >= PORT_MAX){
		fprintf(stderr,"error: invalid port '%hu'\n", port);
		exit(2);
	}
	return (uint16_t) port;
}
